jQuery(function($){
	$('#slz-extension-docs a:slz-external').attr('target', '_blank');
});